#ifndef _DEEPSLEEPDC_H
#define _DEEPSLEEPDC_H

#include <Arduino.h>

void sleep_check(void);

void wake_from_sleep(void);

#endif // _DEEPSLEEPDC_H
