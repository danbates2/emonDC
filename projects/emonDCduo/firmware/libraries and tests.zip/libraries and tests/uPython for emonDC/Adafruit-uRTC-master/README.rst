Adafruit uRTC Library
*********************

A MicroPython library for interfacing with various real-time clock modules.

For full documentation see http://micropython-urtc.rtfd.io/.
