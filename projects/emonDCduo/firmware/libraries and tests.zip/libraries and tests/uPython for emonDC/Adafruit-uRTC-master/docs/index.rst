.. uRTC documentation master file, created by
   sphinx-quickstart on Sun Aug 14 13:58:21 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Adafrauit uRTC's documentation!
==========================================

This is a MicroPython library that makes it easy to communicate with a number
of different real-time clock modules.


Contents:

.. toctree::
    :maxdepth: 2

    install
    urtc
    examples


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

