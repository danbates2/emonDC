
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2020 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f3xx_hal.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* USER CODE BEGIN Includes */
#include <stdbool.h>
#include <string.h>
#include <stdint.h>
#include "RFM69.h"
#include "RFM69_ext.h"
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
char log_buffer[100];

uint16_t networkID = 100; // a.k.a. Network Group
uint8_t nodeID = 1;
uint16_t freqBand = 433;
uint8_t toAddress = 1;
bool requestACK = false;
typedef struct {
  unsigned long nodeId; //store this nodeId
  unsigned long uptime; //uptime in ms
  //float         temp;   // testing
} Payload;
Payload theData;


uint32_t previous_millis = 0;
extern const uint16_t adc_buff_half_size;

volatile int interval = 2500; // post rate (milliseconds)

bool readings_ready = false;

typedef struct channel_
{
  uint64_t sum_V;
  int64_t sum_I;
  // int64_t sum_P;
  uint32_t count;
} channel_t;

#define CHANNELS 2
static channel_t channels[CHANNELS];
static channel_t channels_copy[CHANNELS];


// emonDC settings
float R1 = 1000.0; // kOhms
float R2 = 75.0; // "
float shunt = 0.005; // Ohms
int shunt_mon_gain = 100; 
const float volts_per_div = 3.3/4096;

// adc value to Amps function:
float make_readable_Amps (float _adcValue)
{
  float _readable_1 = _adcValue * volts_per_div;
  float _readable_2 = _readable_1 / shunt_mon_gain; // gives mV signal value.

  float _readable_current = _readable_2 / shunt; // I=V/R
  return (_readable_current);
}

float Vcal_coefficient_A_pre;
float Vcal_coefficient_A;

// adc value to Volts function:
float make_readable_Volts (float _adcValue) {
  float _readableV1 = _adcValue * volts_per_div;
  
  float _readableV2 = _readableV1 / Vcal_coefficient_A;
  return (_readableV2);
}

// The Period of a 200Hz wavecycle is
// 0.005s or 5 milliseconds.
// clock freq is 64Mhz. 614cycles per conversion. 0.00000959375 seconds per converion, or 9.6usecs
// to detect a spike change at the ADC input, 5 milliseconds worth of samples need holding.
// 5000/9.6 = 520 samples approx. 
// if 200Hz is the cutoff frequency then a change of x quantity over t time represents a fast change, 
// a.k.a. a significant event, such as switching on a Load.
// a change of 0.707 (sqrt(0.5)) from one sample to 520 samples later triggers the event in this case, for 200Hz cutoff...
// sqrt(0.5) as a standard design target quantity of amplitude reduction (3db).

//int rate_of_change_I;
//int rate_of_change_V;
// the previous sample's 0.707 = 
uint16_t sample_I;
uint16_t sample_V;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
void process_frame(uint16_t offset)
{
  for (int i = 0; i < adc_buff_half_size; i += 4)
  {
    channel_t *channelA = &channels[0];
    channel_t *channelB = &channels[1];
    
    uint16_t sample_I, sample_V;

    // CH_A
    sample_I = adc1_dma_buff[offset + i];
    sample_V = adc1_dma_buff[offset + (i + 1)];
    channelA->sum_V += sample_V;
    channelA->sum_I += sample_I;
    channelA->count++;

    // CH_B
    sample_I = adc1_dma_buff[offset + (i + 2)];
    sample_V = adc1_dma_buff[offset + (i + 3)];
    channelB->sum_V += sample_V;
    channelB->sum_I += sample_I;
    channelB->count++;

    uint32_t current_millis = HAL_GetTick();
    if (current_millis >= (previous_millis + interval)) // interval here
    {
      int correction = current_millis - previous_millis - interval;
      previous_millis = current_millis - correction;

      channel_t *chn_cpyA = &channels_copy[0];
      channel_t *chn_cpyB = &channels_copy[1];
      
      // Copy accumulators for use in main loop
      memcpy((void *)chn_cpyA, (void *)channelA, sizeof(channel_t));
      memcpy((void *)chn_cpyB, (void *)channelB, sizeof(channel_t));
      // Reset accumulators to zero ready for next set of measurements
      memset((void *)channelA, 0, sizeof(channel_t));
      memset((void *)channelB, 0, sizeof(channel_t));

      readings_ready = true;
    }
  }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  Vcal_coefficient_A_pre = R1 + R2; // resistor divider calc.
  Vcal_coefficient_A = R2 / Vcal_coefficient_A_pre;
  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  MX_TIM8_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */

  debug_printf("\r\nstart\r\n");
  

  RFM69_RST();
  HAL_Delay(10);
  if (RFM69_initialize(freqBand, nodeID, networkID)) {
    sprintf(log_buffer, "RFM69 Initialized. Freq %dMHz. Node %d. Group %d.\r\n", freqBand, nodeID, networkID);
    debug_printf(log_buffer);
    RFM69_readAllRegs();
  }
  else {
    debug_printf("RFM69 not connected.\r\n");
  }
  

  //sprintf(log_buffer, "%ld\r\n", adc_buff_half_size);
  //debug_printf(log_buffer);

  start_ADCs();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

    // SAMPLE RECEIVE CODE
        if (RFM69_ReadDIO0Pin()) {
          //HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, 1); // turn on LED
          RFM69_interruptHandler();
        }
        if (RFM69_receiveDone()) {
          debug_printf("Payload Received!\r\n");
          PrintRawBytes();
          PrintStruct();
          PrintByteByByte();
          //HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, 0); // turn off LED
        }
         /*
        // SAMPLE TRANSMIT CODE
        theData.nodeId = 20;
        theData.uptime = HAL_GetTick();
        RFM69_send(toAddress, (const void *)(&theData), sizeof(theData), requestACK);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, 1); // turn on LED
        HAL_Delay(1);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, 0); // turn off LED
        HAL_Delay(2000);                         // send every ____ milliseconds.
        debug_printf("Payload Sent!\r\n");
        */  


    if (readings_ready)
    {
      //debug_printf("readings ready!\r\n");
      readings_ready = false;

      for (int ch = 0; ch < CHANNELS; ch++)
      {
        channel_t *chn = &channels_copy[ch];

        float Vmean = (float)chn->sum_V / (float)chn->count;
        float Imean = (float)chn->sum_I / (float)chn->count;
        // float Pmean = (float)chn->sum_P / (float)chn->count;

        float Vreadable = make_readable_Volts(Vmean);
        float Ireadable = make_readable_Amps(Imean);
        float Preadable = Ireadable * Vreadable;

        int _ch = ch + 1;
        sprintf(log_buffer, "V%d:%.2f,", _ch, Vreadable);
        debug_printf(log_buffer);
        sprintf(log_buffer, "I%d:%.2f,", _ch, Ireadable);
        debug_printf(log_buffer);
        sprintf(log_buffer, "P%d:%.2f,", _ch, Preadable);
        debug_printf(log_buffer);
      }

      uint32_t current_millis = HAL_GetTick();
      sprintf(log_buffer, "Tck:%ld\r\n", current_millis);
      debug_printf(log_buffer);
    }

  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_I2C1
                              |RCC_PERIPHCLK_TIM8;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_SYSCLK;
  PeriphClkInit.Tim8ClockSelection = RCC_TIM8CLK_HCLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
