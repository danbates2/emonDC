#include "AB08XX_SPI_Linux.h"
#include "AB08XX_CLI.h"
#include "Arduino.h"
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>
#include <string.h> /* memset */
#include <unistd.h> /* close */
#include <time.h>

/*
 * SPI testing utility (using spidev driver)
 *
 * Copyright (c) 2007  MontaVista Software, Inc.
 * Copyright (c) 2007  Anton Vorontsov <avorontsov@ru.mvista.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License.
 *
 * Cross-compile with cross-gcc -I/path/to/cross-kernel/include
 */


static const char *device = "/dev/spidev0.0";
static uint8_t mode;
static uint8_t bits = 8;
static uint32_t speed = 500000;
static uint16_t _delay;
static bool set_timestamp = false;
static bool use_localtime = false;

static void print_usage(const char *prog)
{
	printf("Usage: %s [-DstTbdlHOLC3]\n", prog);
	puts("  -D --device   device to use (default /dev/spidev1.1)\n"
	     "  -s --speed    max speed (Hz)\n"
	     "  -d --delay    delay (usec)\n"
	     "  -b --bpw      bits per word \n"
	     "  -l --loop     loopback\n"
	     "  -H --cpha     clock phase\n"
	     "  -O --cpol     clock polarity\n"
	     "  -L --lsb      least significant bit first\n"
	     "  -C --cs-high  chip select active high\n"
	     "  -t --write-utc set the spi clock from the system time (UTC)\n"
	     "  -T --write-localtime set the spi clock from the system time (UTC + timezone)\n"
	     "  -3 --3wire    SI/SO signals shared\n");
	exit(1);
}

static void parse_opts(int argc, char *argv[])
{
	while (1) {
		static const struct option lopts[] = {
			{ "device",  1, 0, 'D' },
			{ "speed",   1, 0, 's' },
			{ "delay",   1, 0, 'd' },
			{ "bpw",     1, 0, 'b' },
			{ "loop",    0, 0, 'l' },
			{ "cpha",    0, 0, 'H' },
			{ "cpol",    0, 0, 'O' },
			{ "lsb",     0, 0, 'L' },
			{ "cs-high", 0, 0, 'C' },
			{ "3wire",   0, 0, '3' },
			{ "no-cs",   0, 0, 'N' },
			{ "write-utc",    0, 0, 't' },
			{ "write-localtime",    0, 0, 'T' },
			{ "ready",   0, 0, 'R' },
			{ NULL, 0, 0, 0 },
		};
		int c;

		c = getopt_long(argc, argv, "D:s:d:b:lHOLC3NRtT", lopts, NULL);

		if (c == -1)
			break;

		switch (c) {
		case 'D':
			device = optarg;
			break;
		case 's':
			speed = atoi(optarg);
			break;
		case 'd':
			_delay = atoi(optarg);
			break;
		case 'b':
			bits = atoi(optarg);
			break;
		case 'l':
			mode |= SPI_LOOP;
			break;
		case 'H':
			mode |= SPI_CPHA;
			break;
		case 'O':
			mode |= SPI_CPOL;
			break;
		case 'L':
			mode |= SPI_LSB_FIRST;
			break;
		case 'C':
			mode |= SPI_CS_HIGH;
			break;
		case '3':
			mode |= SPI_3WIRE;
			break;
		case 'N':
			mode |= SPI_NO_CS;
			break;
		case 'R':
			mode |= SPI_READY;
			break;
		case 'T':
			use_localtime = true;
		case 't':
			set_timestamp = true;
			break;
		default:
			print_usage(argv[0]);
			break;
		}
	}
}

int cli_main(AB08XX *_clock)
{
    abclock = _clock;
    Serial.println();
    help(1, (char**) "");
    Serial.println();
    Serial.println("Enter \"help\" for list of available commands.");
    prompt();
    while(true)
    {
        loop();
    }
    return 0;
}

int main(int argc, char *argv[])
{
    parse_opts(argc, argv);

    Serial.begin();
    AB08XX_SPI_Linux clock(device, mode, bits, speed, _delay);

    if(set_timestamp)
    {
	ab08xx_tmElements_t tm;
	time_t ts = time(NULL);
	struct tm *lt = localtime(&ts);
	if(use_localtime)
	{
		ts += lt->tm_gmtoff;
	}
	breakTime(ts, tm);	
	clock.write(tm);	
    }

    return cli_main(&clock);
}

int exit(int argc, char** argv)
{
	exit(0);
}
