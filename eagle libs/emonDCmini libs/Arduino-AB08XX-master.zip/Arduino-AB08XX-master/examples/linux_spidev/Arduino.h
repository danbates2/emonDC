#ifndef __ARDUINO_H__
#define __ARDUINO_H__

#include "stdint.h"
#include "stddef.h"
#include "stdlib.h"
#include "string.h"
#include "AString.h"
#include "HardwareSerial.h"

#endif
