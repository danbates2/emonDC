Free to use.

SHUNT MONITOR BREAKOUT BOARD FOR LMP8481 or similar chips.

openenergymonitor.org